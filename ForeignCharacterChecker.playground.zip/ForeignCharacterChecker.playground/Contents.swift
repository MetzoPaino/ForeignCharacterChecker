//: Playground - noun: a place where people can play

import Cocoa

let foreignString = "Öswald"
let uppercaseForeignString = foreignString.uppercaseStringWithLocale(NSLocale.systemLocale())
let characterArray = Array(foreignString.characters)

var hasCapital = false

for (index, character) in characterArray.enumerate() {
    
    let uppercaseCharacter = uppercaseForeignString[uppercaseForeignString.startIndex.advancedBy(index)]
    
    if character == uppercaseCharacter {
        hasCapital = true
        print(character)
    }
}